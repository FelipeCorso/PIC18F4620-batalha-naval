/*
 * Project name:
     SPI_Lcd_COG_2x16 (Simple demonstration of the SPI Lcd 4-bit Library functions)
 * Copyright:
     (c) Mikroelektronika, 2009.
 * Revision History:
     20090505:
       - initial release;
       - 20090720 - modified by Slavisa Zlatanovic;
 * Description:
     This is a simple demonstration of SPI Lcd 4-bit library functions.
     SPI Lcd Library sends commands to Port Expander and it controls
     Port Expander's output Port1 (connected to Serial LCD).
 * Test configuration:
     MCU:             PIC16F887
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41291F.pdf
     Dev.Board:       EasyPIC6
                      http://www.mikroe.com/en/tools/easypic6/
     Oscillator:      HS, 8.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Turn on Port Expander switches SW6.1, SW6.2, SW6.3, SW6.4 and SW6.5.
     - Turn on COG LCD 2x16 switches SW10.1, SW10.2, SW10.3, SW10.4, SW10.5 and SW10.6.
*/

char *text = "www.mikroe.com";

// Port Expander module connections
sbit  SPExpanderCS  at RA2_bit;
sbit  SPExpanderRST at RA3_bit;
sbit  SPExpanderCS_Direction  at TRISA2_bit;
sbit  SPExpanderRST_Direction at TRISA3_bit;
// End Port Expander module connections

char i;                                     // Loop variable

void Move_Delay() {                         // Function used for text moving
  Delay_ms(500);                            // You can change the moving speed here
}

void main() {

  ANSEL  = 0;                               // Configure AN pins as digital
  ANSELH = 0;
  C1ON_bit = 0;                             // Disable comparators
  C2ON_bit = 0;

// Port Expander Library uses SPI1 module
  SPI1_Init();                              // Initialize SPI module used with PortExpander

  SPI_Lcd_Config(0);                        // Initialize Lcd over SPI interface
  SPI_Lcd_Cmd(_LCD_CLEAR);                  // Clear display
  SPI_Lcd_Cmd(_LCD_CURSOR_OFF);             // Turn cursor off
  SPI_Lcd_Out(1,1, "mikroElektronika");     // Print text to Lcd, 1st row, 1st column
  SPI_Lcd_Out(2,2, text);                   // Print text to Lcd, 2nd row, 2nd column
  
  Delay_1sec();
  Delay_1sec();
  
// Moving text
  for(i=0; i<4; i++) {                      // Move text to the right 4 times
    SPI_Lcd_Cmd(_LCD_SHIFT_RIGHT);
    Move_Delay();
  }

  while(1) {                                // Endless loop
    for(i=0; i<8; i++) {                    // Move text to the left 7 times
      SPI_Lcd_Cmd(_LCD_SHIFT_LEFT);
      Move_Delay();
    }

    for(i=0; i<8; i++) {                    // Move text to the right 7 times
      SPI_Lcd_Cmd(_LCD_SHIFT_RIGHT);
      Move_Delay();
    }
  }
}
