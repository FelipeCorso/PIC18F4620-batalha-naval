/*
 * Project name:
     PS2_Example (Demonstration on using PS/2 keyboard library)
 * Copyright:
     (c) Mikroelektronika, 2009.
 * Revision History:
     20081218:
       - initial release;
       - 20090720 - modified by Slavisa Zlatanovic;
 * Description:
     In this example, key(s) pressed on the PS/2 keyboard are read and transferred
     to PC through serial port connection. Various basic keyboard activities are
     tested: "normal" keys, keys with <Shift> pressed, keys with <Caps Lock>
     pressed, numerical keypad ON/OFF and keys. The result is visible on PC, on
     USART Terminal tool.
 * Test configuration:
     MCU:             PIC16F887
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41291F.pdf
     Dev.Board:       EasyPIC6
                      http://www.mikroe.com/en/tools/easypic6/
     Oscillator:      HS, 8.000 MHz
     Ext. Modules:    Standard PS2 keyboard
                      http://en.wikipedia.org/wiki/Keyboard_(computing)
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Some keyboards with various multimedia attachments on them 
       tend to "choke" the communication by constantly sending
       requests on various multimedia objects status (volume, mouse pos. etc.).
       This may slow down the communication pace with the MCU.
     - Diodes off (SW9.3) and pull-ups (place jumper J3 in upper position)
       on PS2 lines may be required.
     - Turn on UART switches on SW7.1 and SW8.1 (board specific).
     - PS/2 jumpers ON (J20,J21).
 */


unsigned short keydata = 0, special = 0, down = 0;
 
sbit PS2_Data            at RC0_bit;
sbit PS2_Clock           at RC1_bit;
sbit PS2_Data_Direction  at TRISC0_bit;
sbit PS2_Clock_Direction at TRISC1_bit;

void main() {

  ANSEL  = 0;                                         // Configure AN pins as digital I/O
  ANSELH = 0;
  C1ON_bit = 0;                                       // Disable comparators
  C2ON_bit = 0;
  
  UART1_Init(19200);                                  // Initialize UART module at 19200 bps
  Ps2_Config();                                       // Init PS/2 Keyboard
  Delay_ms(100);                                      // Wait for keyboard to finish
  UART1_Write_Text("Ready");
  UART1_Write(10);                                    // Line Feed
  UART1_Write(13);                                    // Carriage return

  do {
    if (Ps2_Key_Read(&keydata, &special, &down)) {
      if (down && (keydata == 16)) {                  // Backspace
         UART1_Write(0x08);
      }
      else if (down && (keydata == 13)) {             // Enter
        UART1_Write('\r');                            // send carriage return to usart terminal
        //Usart_Write('\n');                          // uncomment this line if usart terminal also expects line feed
                                                      // for new line transition
      }
      else if (down && !special && keydata) {
        UART1_Write(keydata);
      }
    }
    Delay_ms(1);                                      // debounce
  } while (1);
}
