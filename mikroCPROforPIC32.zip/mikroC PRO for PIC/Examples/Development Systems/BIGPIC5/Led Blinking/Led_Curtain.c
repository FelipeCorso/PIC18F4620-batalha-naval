/*
 * Project name:
     LED_Blinking (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     This is a simple 'Hello World' project. It turns on/off LEDs connected to
     PORTB, PORTC and PORTD.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Turn ON the PORT LEDs at SW5. (board specific)
*/
char counter;

void wait() {
  Delay_ms(100);
}

void main() {

  ADCON1 |= 0x0F;      // Configure AN pins as digital
  CMCON  |= 7;         // Disable comparators

  TRISB = 0x00;        // set direction to be output
  TRISC = 0x00;        // set direction to be output
  TRISD = 0x00;        // set direction to be output
  PORTB = 0x00;        // turn OFF the PORTB leds
  PORTC = 0x00;        // turn OFF the PORTC leds
  PORTD = 0x00;        // turn OFF the PORTD leds
  
  while (1) {
    for (counter=0; counter<8; counter++){
      PORTB |= 1 << counter;
      PORTC |= 1 << counter;
      PORTD |= 1 << counter;
 
      wait();
    }
       
    counter = 0;
    while (counter<8) {
      PORTB &= ~(1 << counter);
      PORTC &= ~(1 << counter);
      PORTD &= ~(1 << counter);
 
      wait();
      counter++;
    }
  }
}
