/*
 * Project name:
      SPI (Driving external Digital-to-Analog converter)
 * Copyright:
     (c) mikroElektronika, 2008.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     This is a sample program which demonstrates the use of the Microchip's
     MCP4921 12-bit D/A converter. This device accepts digital
     input (number from 0..4095) and transforms it to the output voltage,
     ranging from 0..Vref. In this example the DAC communicates with MCU
     through the SPI communication.
     Buttons RB0 and RB1 are used to change value sent to DAC.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    on-board DAC module
                      http://www.mikroe.com/pdf/bigpic5/bigpic5_manual.pdf#page=36
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Turn on SPI (SW4.1, SW4.2, SW4.3) and DAC (SW3.6, SW3.7)
       switches on development board. (board specific)
     - Put button jumper (J11) into VCC position and pull-down PORTB. (board specific)
     - Voltage reference jumper J16 should be connected (board specific).
 */

// DAC module connections
sbit Chip_Select at LATE1_bit;  // for writing to output pin always use latch (PIC18 family)
sbit Chip_Select_Direction at TRISE1_bit;
sbit DAC_Load at LATE2_bit;  // for writing to output pin always use latch (PIC18 family)
sbit DAC_Load_Direction at TRISE2_bit;
// End DAC module connections

// Control buttons connections
sbit Button_Inc  at RB0_bit;
sbit Button_Dec  at RB1_bit;
sbit Button_Inc_Direction  at TRISB0_bit;
sbit Button_Dec_Direction  at TRISB1_bit;
// eof control buttons connections

unsigned int value;                     

void InitMain() {

  ADCON1 |= 0x0F;                         // Configure AN pins as digital
  CMCON  |= 7;                            // Disable comparators
  
  Button_Inc_Direction = 1;               // Set INC button pin as input
  Button_Dec_Direction = 1;               // Set DEC button pin as input
  Chip_Select = 1;                        // Deselect DAC
  Chip_Select_Direction = 0;              // Set CS# pin as Output
  DAC_Load = 0;                           // Enable DAC load
  DAC_Load_Direction = 0;                 // Set DAC load pin as Output

  // If DAC is connected to SPI1 module
  SPI1_Init();                            // Initialize SPI1 module
//  // If DAC is connected to SPI2 module
//  SPI2_Init();                            // Initialize SPI2 module
}

// DAC increments (0..4095) --> output voltage (0..Vref)
void DAC_Output(unsigned int valueDAC) {
  char temp;
 
  Chip_Select = 0;                        // Select DAC chip
  
  // Send High Byte                                         
  temp = (valueDAC >> 8) & 0x0F;          // Store valueDAC[11..8] to temp[3..0]
  temp |= 0x30;                           // Define DAC setting, see MCP4921 datasheet
  SPI1_Read(temp);                        // Send high byte via SPI
  
  // Send Low Byte
  temp = valueDAC;                        // Store valueDAC[7..0] to temp[7..0]
  SPI1_Read(temp);                        // Send low byte via SPI
  
  Chip_Select = 1;                        // Deselect DAC chip
}

void main() {

  InitMain();                             // Perform main initialization

  value = 2048;                           // When program starts, DAC gives
                                          //   the output in the mid-range

  while (1) {                             // Endless loop

    if (Button_Inc && (value < 4095)) {   // If INC button is pressed
      value++;                            //   increment value
      }
    else {
      if (Button_Dec && (value > 0)) {    // If DEC button is pressed
        value--;                          //   decrement value
        }
      }

    DAC_Output(value);                    // Send value to DAC chip
    Delay_ms(1);                          // Slow down key repeat pace
  }
}
