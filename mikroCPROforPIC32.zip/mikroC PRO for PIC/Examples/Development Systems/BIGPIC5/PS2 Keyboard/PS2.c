/*
 * Project name:
     PS2_Example (Demonstration on using PS/2 keyboard library)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     In this example, key(s) pressed on the PS/2 keyboard are read and transferred
     to PC through serial port connection. Various basic keyboard activities are
     tested: "normal" keys, keys with <Shift> pressed, keys with <Caps Lock>
     pressed, numerical keypad ON/OFF and keys. The result is visible on PC, on
     USART Terminal tool.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    Standard PS2 keyboard
                      http://en.wikipedia.org/wiki/Keyboard_(computing)
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Some keyboards with various multimedia attachments on them 
       tend to "choke" the communication by constantly sending
       requests on various multimedia objects' status (volume, mouse pos. etc.).
       This may slow down the communication pace with the MCU.
     - Turn on PS2 switches SW3.1 and SW3.2 (board specific).
     - Pull-up PORTC and turn off PORTC LEDs (board specific).
     - Connect the RS232 cable and jumpers J12 and J13 (board specific).
 */


unsigned short keydata = 0, special = 0, down = 0;
 
sbit PS2_Data            at RC0_bit;
sbit PS2_Clock           at RC1_bit;
sbit PS2_Data_Direction  at TRISC0_bit;
sbit PS2_Clock_Direction at TRISC1_bit;

void main() {

  ADCON1 |= 0x0F;           // Configure AN pins as digital
  CMCON  |= 7;              // Disable comparators

  UART1_Init(19200);        // Initialize UART module at 19200 bps
  Ps2_Config();             // Init PS/2 Keyboard
  Delay_ms(100);            // Wait for keyboard to finish
  UART1_Write_Text("Ready");

  do {
    if (Ps2_Key_Read(&keydata, &special, &down)) {
      if (down && (keydata == 16)) {// Backspace
         UART1_Write(0x08);
      }
      else if (down && (keydata == 13)) {// Enter
        UART1_Write('\r');               // send carriage return to usart terminal
        //Usart_Write('\n');             // uncomment this line if usart terminal also expects line feed
                                         // for new line transition
      }
      else if (down && !special && keydata) {
        UART1_Write(keydata);
      }
    }
    Delay_ms(1);            // debounce
  } while (1);
}
