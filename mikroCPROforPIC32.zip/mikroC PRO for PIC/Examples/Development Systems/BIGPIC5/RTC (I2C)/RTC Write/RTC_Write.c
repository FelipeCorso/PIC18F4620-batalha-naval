/*
 * Project name:
     RTC_Write (Demonstration on working with the RTC Module and I2C routines)
 * Copyright:
     (c) mikroElektronika, 2008.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     This project is simple demonstration how to set date and time on PCF8583
     RTC (real-time clock).
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    on-board RTC module
                      http://www.mikroe.com/pdf/bigpic5/bigpic5_manual.pdf#page37
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - I2C communication lines PORTC should be connected (jumper J3)
       to pull-up resistors (board specific)
     - Turn off PORTC LEDs SW5 connected to I2C communication lines.(board specific)
     - In order to use the example, address pin A0 of PCF8583 must be set to 0V.
       (on mikroElektronika's RTC module this is done by default)
 */

void main() {

  ADCON1 |= 0x0F;           // Configure AN pins as digital
  CMCON  |= 7;              // Disable comparators

  Delay_ms(1000);

  I2C1_Init(100000);        // Initialize full master mode
  I2C1_Start();             // Issue start signal
  I2C1_Wr(0xA0);            // Address PCF8583, see PCF8583 datasheet
  I2C1_Wr(0);               // Start from address 0 (configuration memory location)
  I2C1_Wr(0x80);            // Write 0x80 to configuration memory location (pause counter...)
  I2C1_Wr(0);               // Write 0 to cents memory location
  I2C1_Wr(0);               // Write 0 to seconds memory location
  I2C1_Wr(0x30);            // Write 0x30 to minutes memory location
  I2C1_Wr(0x12);            // Write 0x12 to hours memory location
  I2C1_Wr(0x24);            // Write 0x24 to year/date memory location
  I2C1_Wr(0x08);            // Write 0x08 to weekday/month memory location
  I2C1_Stop();              // Issue stop signal

  I2C1_Start();             // Issue start signal
  I2C1_Wr(0xA0);           // Address PCF8530
  I2C1_Wr(0);               // Start from address 0
  I2C1_Wr(0);               // Write 0 to configuration memory location (enable counting)
  I2C1_Stop();              // Issue stop signal
}
