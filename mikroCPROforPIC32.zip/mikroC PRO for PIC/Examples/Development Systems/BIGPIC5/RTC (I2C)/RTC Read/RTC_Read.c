/*
 * Project name:
     RTC_Read (Demonstration on working with the RTC Module and I2C routines)
 * Copyright:
     (c) mikroElektronika, 2008.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     This project is simple demonstration how to read date and time from
     PCF8583 RTC (real-time clock).
     Date and time are read from the RTC every 1 second and printed on LCD.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    on-board RTC module
                      http://www.mikroe.com/pdf/bigpic5/bigpic5_manual.pdf#page37
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - I2C communication lines PORTC should be connected (jumper J3)
       to pull-up resistors (board specific)
     - Turn off PORTC LEDs SW5 connected to I2C communication lines.(board specific)
     - In order to use the example, address pin A0 of PCF8583 must be set to 0V.
       (on mikroElektronika's RTC module this is done by default)
*/

char seconds, minutes, hours, day, month, year;    // Global date/time variables

// LCD module connections
sbit LCD_RS at LATD2_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_EN at LATD3_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D4 at LATD4_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D5 at LATD5_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D6 at LATD6_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D7 at LATD7_bit;  // for writing to output pin always use latch (PIC18 family)

sbit LCD_RS_Direction at TRISD2_bit;
sbit LCD_EN_Direction at TRISD3_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;
// End LCD module connections


//--------------------- Reads time and date information from RTC (PCF8583)
void Read_Time() {

  I2C1_Start();            // Issue start signal
  I2C1_Wr(0xA0);           // Address PCF8583, see PCF8583 datasheet
  I2C1_Wr(2);              // Start from address 2
  
  I2C1_Repeated_Start();   // Issue repeated start signal
  I2C1_Wr(0xA1);           // Address PCF8583 for reading R/W=1
  seconds = I2C1_Rd(1);    // Read seconds byte
  minutes = I2C1_Rd(1);    // Read minutes byte
  hours = I2C1_Rd(1);      // Read hours byte
  day = I2C1_Rd(1);        // Read year/day byte
  month = I2C1_Rd(0);      // Read weekday/month byte
  I2C1_Stop();             // Issue stop signal
  
}

//-------------------- Formats date and time
void Transform_Time() {
  seconds  =  ((seconds & 0xF0) >> 4)*10 + (seconds & 0x0F);  // Transform seconds
  minutes  =  ((minutes & 0xF0) >> 4)*10 + (minutes & 0x0F);  // Transform months
  hours    =  ((hours & 0xF0)  >> 4)*10  + (hours & 0x0F);    // Transform hours
  year     =   (day & 0xC0) >> 6;                             // Transform year
  day      =  ((day & 0x30) >> 4)*10    + (day & 0x0F);       // Transform day
  month    =  ((month & 0x10)  >> 4)*10 + (month & 0x0F);     // Transform month
}

//-------------------- Output values to LCD
void Display_Time() {

   Lcd_Chr(1, 6, (day / 10)   + 48);    // Print tens digit of day variable
   Lcd_Chr(1, 7, (day % 10)   + 48);    // Print oness digit of day variable
   Lcd_Chr(1, 9, (month / 10) + 48);
   Lcd_Chr(1,10, (month % 10) + 48);
   Lcd_Chr(1,15,  year        + 56);    // Print year vaiable + 8 (start from year 2008)

   Lcd_Chr(2, 6, (hours / 10)   + 48);
   Lcd_Chr(2, 7, (hours % 10)   + 48);
   Lcd_Chr(2, 9, (minutes / 10) + 48);
   Lcd_Chr(2,10, (minutes % 10) + 48);
   Lcd_Chr(2,12, (seconds / 10) + 48);
   Lcd_Chr(2,13, (seconds % 10) + 48);
}

//------------------ Performs project-wide init
void Init_Main() {

  ADCON1 |= 0x0F;            // Configure AN pins as digital
  CMCON  |= 7;               // Disable comparators

  I2C1_Init(100000);         // Initialize Soft I2C communication
  
  Lcd_Init();                // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);       // Clear LCD display
  Lcd_Cmd(_LCD_CURSOR_OFF);  // Turn cursor off

  Lcd_Out(1,1,"Date:");      // Prepare and output static text on LCD
  Lcd_Chr(1,8,':');
  Lcd_Chr(1,11,':');
  Lcd_Out(2,1,"Time:");
  Lcd_Chr(2,8,':');
  Lcd_Chr(2,11,':');
  Lcd_Out(1,12,"200");
}

//----------------- Main procedure
void main() {
  Init_Main();               // Perform initialization

  while (1) {                // Endless loop
    Read_Time();             // Read time from RTC(PCF8583)
    Transform_Time();        // Format date and time
    Display_Time();          // Prepare and display on LCD

    Delay_ms(1000);          // Wait 1 second
  }
}
