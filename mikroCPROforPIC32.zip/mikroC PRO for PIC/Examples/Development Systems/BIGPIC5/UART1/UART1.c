/*
 * Project name:
     UART1 (Simple usage of UART1 module library functions)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     This code demonstrates how to use UART1 library routines. Upon receiving
     data via RS232, MCU immediately sends it back to the sender.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Connect UART1 jumpers J12 and J13 (board specific).
*/

char uart_rd;

void main() {

  ADCON1 |= 0x0F;                 // Configure AN pins as digital
  CMCON  |= 7;                    // Disable comparators

  UART1_Init(9600);               // Initialize UART module at 9600 bps
  Delay_ms(100);                  // Wait for UART module to stabilize

  UART1_Write_Text("Start");
  while (1) {                     // Endless loop
   if (UART1_Data_Ready()) {      // If data is received,
     uart_rd = UART1_Read();      //   read the received data,
     UART1_Write(uart_rd);        //   and send data via UART
    }
  }
}
