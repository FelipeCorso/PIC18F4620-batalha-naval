/*
 * Project name:
     Can_Spi_2nd (CAN Network demonstration with mikroE's CAN-SPI module)
 * Copyright:
     (c) MikroElektronika, 2005-2008
 * Description:
     This project is a simple demonstration of using CAN-SPI module; with minor
     adjustments, it should work with any other MCU that has a SPI module.
     This code demonstrates how to use CANSPI library functions and procedures.
     It is used together with the CanSpi_1st example (on second MCU), and it can
     be used to test the connection of MCU to the CAN network.
     This node receives data, increments it by 1 and send it back to the 1st node.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    on-board CAN-SPI module
                      http://www.mikroe.com/pdf/bigpic5/bigpic5_manual.pdf#page=34
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Turn ON the PORTD LEDs.
     - Turn on CAN (SW3.3, SW3.4, SW3.5) and SPI switches(SW4.1, SW4.2, SW4.3)
       on board. (board specific)
     - Consult the CAN standard about CAN bus termination resistance. 
*/

unsigned char Can_Init_Flags, Can_Send_Flags, Can_Rcv_Flags;  // can flags
unsigned char Rx_Data_Len;                                    // received data length in bytes
char RxTx_Data[8];                                            // can rx/tx data buffer
char Msg_Rcvd;                                                // reception flag
const long ID_1st = 12111, ID_2nd = 3;                        // node IDs
long Rx_ID;

// CANSPI module connections
sbit CanSpi_CS            at LATE3_bit;  // for writing to output pin always use latch (PIC18 family)
sbit CanSpi_CS_Direction  at TRISE3_bit;
sbit CanSpi_Rst           at LATE4_bit;  // for writing to output pin always use latch (PIC18 family)
sbit CanSpi_Rst_Direction at TRISE4_bit;
// End CANSPI module connections


void main() {

  ADCON1 |= 0x0F;                                             // Configure AN pins as digital
  CMCON  |= 7;                                                // Disable comparators
  
  PORTD = 0;                                                  // clear PORTD
  TRISD = 0;                                                  // set PORTD as output

  Can_Init_Flags = 0;                                         //
  Can_Send_Flags = 0;                                         // clear flags
  Can_Rcv_Flags  = 0;                                         //

  Can_Send_Flags = _CANSPI_TX_PRIORITY_0 &                    // form value to be used
                   _CANSPI_TX_XTD_FRAME &                     //   with CANSPIWrite
                   _CANSPI_TX_NO_RTR_FRAME;

  Can_Init_Flags = _CANSPI_CONFIG_SAMPLE_THRICE &             // Form value to be used
                   _CANSPI_CONFIG_PHSEG2_PRG_ON &             //  with CANSPIInit
                   _CANSPI_CONFIG_XTD_MSG &
                   _CANSPI_CONFIG_DBL_BUFFER_ON &
                   _CANSPI_CONFIG_VALID_XTD_MSG &
                   _CANSPI_CONFIG_LINE_FILTER_OFF;

 // If CAN-SPI is connected to SPI1 module
  SPI1_Init();                                                // Initialize SPI1 module

//  // If CAN-SPI is connected to SPI2 module
//  SPI2_Init();                                               // Initialize SPI2 module

  CANSPIInitialize(1,3,3,3,1,Can_Init_Flags);                                  // initialize external CANSPI module
  CANSPISetOperationMode(_CANSPI_MODE_CONFIG,0xFF);                            // set CONFIGURATION mode
  CANSPISetMask(_CANSPI_MASK_B1,-1,_CANSPI_CONFIG_XTD_MSG);                    // set all mask1 bits to ones
  CANSPISetMask(_CANSPI_MASK_B2,-1,_CANSPI_CONFIG_XTD_MSG);                    // set all mask2 bits to ones
  CANSPISetFilter(_CANSPI_FILTER_B2_F3,ID_1st,_CANSPI_CONFIG_XTD_MSG);         // set id of filter B2_F3 to 1st node ID
  CANSPISetOperationMode(_CANSPI_MODE_NORMAL,0xFF);                            // set NORMAL mode

  while (1) {                                                                  // endless loop
    Msg_Rcvd = CANSPIRead(&Rx_ID , RxTx_Data , &Rx_Data_Len, &Can_Rcv_Flags);  // receive message
    if ((Rx_ID == ID_1st) && Msg_Rcvd) {                                       // if message received check id
      PORTD = RxTx_Data[0];                                                    // id correct, output data at PORTD
      RxTx_Data[0]++ ;                                                         // increment received data
      CANSPIWrite(ID_2nd, RxTx_Data, 1, Can_Send_Flags);                       // send incremented data back
    }
  }
}
