/*
 * Project name:
     RS485_Slave_Example (RS485 Library demo - Slave side)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20080930:
       - initial release;
* Description:
     This is a simple demonstration on how to use the mikroC's RS485 library.
     It is being used in pair with the RS485_Master_Example project. Slave (this
     machine) initializes itself (on address 160) and waits to receive data from
     the master. Then it increments the first byte of received data and sends it
     back to the master. The data received is shown on PORTB, Error on receive
     and number of consecutive unsuccessful retries on PORTC.
     Several situations are shown here:
       - RS485 Slave Init sequence;
       - Data sending slave-to-master;
     Also shown here, but not strictly related to RS485 library, is:
       - Function calling from the interrupt routine - which data is to be saved,
         and how.
     For further explanations on RS485 library, please consult the mikroC Help.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    on-board MMC/SD module
                      http://www.mikroe.com/pdf/bigpic5/bigpic5_manual.pdf#page35
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Initialize the UART module before performing RS485 init.
     - Turn on RS485 switches SW2.6, SW2.7, SW2.8  (board specific)
     - Turn on PORTB LEDs SW5 (board specific)
 */

char dat[9];             // buffer for receving/sending messages
char i,j;

// RS485 module connections
sbit  rs485_rxtx_pin  at LATG0_bit;  // for writing to output pin always use latch (PIC18 family)
sbit  rs485_rxtx_pin_direction at TRISG0_bit; // set transcieve pin direction
// end RS485 module connections

// Interrupt routine
void interrupt() {
  RS485Slave_Receive(dat);
}

void main() {

  ADCON1 |= 0x0F;                      // Configure AN pins as digital
  CMCON  |= 7;                         // Disable comparators
  
  PORTB = 0;                           // clear PORTB
  PORTC = 0;                           // clear PORTC
  TRISB = 0x00;                        // set PORTB as output
  TRISC = 0x00;                        // set PORTB as output


  UART2_Init(9600);                    // initialize UART2 module
  Delay_ms(100);
  RS485Slave_Init(160);                // Intialize MCU as slave, address 160

  dat[4] = 0;                          // ensure that message received flag is 0
  dat[5] = 0;                          // ensure that message received flag is 0
  dat[6] = 0;                          // ensure that error flag is 0

  RC2IE_bit = 1;                       // enable interrupt on UART2 receive
  TX2IE_bit = 0;                       // disable interrupt on UART2 transmit
  PEIE_bit = 1;                        // enable peripheral interrupts
  GIE_bit  = 1;                        // enable all interrupts

  while (1) {
  
    if (dat[5])  {                     // if an error detected, signal it by
      PORTC = dat[5];                  //   setting PORTC
      dat[5] = 0;
    }
    if (dat[4]) {                      // upon completed valid message receive
      dat[4] = 0;                      //   data[4] is set to 0xFF
      j = dat[3];

      for (i = 1; i <= dat[3];i++){    // show data on PORTB
        PORTB = dat[i-1];
      }
      dat[0] = dat[0]+1;               // increment received dat[0]
      Delay_ms(1);
      RS485Slave_Send(dat,1);          //   and send it back to master
    }
  }
}
