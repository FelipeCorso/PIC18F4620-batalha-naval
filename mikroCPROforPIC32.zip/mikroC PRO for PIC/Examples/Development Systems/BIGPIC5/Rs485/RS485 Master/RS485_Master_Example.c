/*
 * Project name:
     RS485_Master_Example (RS485 Library demo - Master side)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     This is a simple demonstration on how to use the RS485 library.
     It is being used in pair with the RS485_Slave_Example project. Master (this
     machine) initiates communication with slave by sending 1 byte of data to
     the slave with designated slave address (160). The slave accepts data,
     increments it and sends it back to the master.
     The data received is shown on PORTB, Error on receive on PORTC and number of
     consecutive unsuccessful retries on PORTA.
     Several situations are shown here:
       - RS485 Master Init sequence;
       - Data sending master-to-slave with designated slave address;
       - Data sending master-to-slave with broadcast slave address (50);
       - Handling of unsuccessful master-slave communication (connection reset);
     Also shown here, but not strictly related to RS485 library, is:
       - Function calling from the interrupt routine - which data is to be saved,
         and how.
     For further explanations on RS485 library, please consult the Help.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC5
                      http://www.mikroe.com/en/tools/bigpic5/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    on-board RS485 module
                      http://www.mikroe.com/pdf/bigpic5/bigpic5_manual.pdf#page35
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Initialize the UART module before performing RS485 init.
     - Turn on RS485 switches SW2.6, SW2.7, SW2.8  (board specific)
     - Turn on PORTB LEDs SW5 (board specific)
 */

char dat[10];                                 // buffer for receving/sending messages
char i,j;

// RS485 module connections
sbit  rs485_rxtx_pin  at LATG0_bit;  // for writing to output pin always use latch (PIC18 family)
sbit  rs485_rxtx_pin_direction at TRISG0_bit; // set transcieve pin direction
// end RS485 module connections


// Interrupt routine
void interrupt() {
  RS485Master_Receive(dat);
}

void main(){
  long cnt = 0;
  
  ADCON1 |= 0x0F;                      // Configure AN pins as digital
  CMCON  |= 7;                         // Disable comparators
  
  PORTA  = 0;                          // clear PORTA
  PORTB  = 0;                          // clear PORTB
  PORTC  = 0;                          // clear PORTC

  TRISA  = 0x00;                       // set PORTA as output
  TRISB  = 0x00;                       // set PORTB as output
  TRISC  = 0x00;                       // set PORTC as output
  

  UART2_Init(9600);                    // initialize UART2 module
  Delay_ms(100);

  RS485Master_Init();                  // initialize MCU as Master
  dat[0] = 0xAA;
  dat[1] = 0xF0;
  dat[2] = 0x0F;
  dat[4] = 0;                          // ensure that message received flag is 0
  dat[5] = 0;                          // ensure that error flag is 0
  dat[6] = 0;

  RS485Master_Send(dat,1,160);

  RC2IE_bit = 1;                       // enable interrupt on UART2 receive
  TX2IE_bit = 0;                       // disable interrupt on UART2 transmit
  PEIE_bit = 1;                        // enable peripheral interrupts
  GIE_bit  = 1;                        // enable all interrupts

  while (1){
                                       // upon completed valid message receiving
                                       //   data[4] is set to 255
    cnt++;
    if (dat[5])  {                     // if an error detected, signal it
      PORTC = dat[5];                  //   by setting PORTC
    }
    if (dat[4]) {                      // if message received successfully
      cnt = 0;
      dat[4] = 0;                      // clear message received flag
      j = dat[3];
      for (i = 1; i <= dat[3]; i++) {  // show data on PORTB
        PORTB = dat[i-1];
      }                                // increment received dat[0]
      dat[0] = dat[0]+1;               // send back to slave
      Delay_ms(1);
      RS485Master_Send(dat,1,160);

    }

    if (cnt > 100000) {                // if in 100000 poll-cycles the answer
      PORTA++;                         //   was not detected, signal
      cnt = 0;                         //   failure of send-message
      RS485Master_Send(dat,1,160);
      if (PORTA > 10){                 // if sending failed 10 times
        PORTA = 0;
        RS485Master_Send(dat,1,50);    //   send message on broadcast address
      }
     }
  }
}
