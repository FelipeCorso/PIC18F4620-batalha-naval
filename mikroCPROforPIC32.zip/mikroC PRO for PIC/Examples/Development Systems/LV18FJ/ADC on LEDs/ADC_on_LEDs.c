/*
 * Project name:
     ADC_on LEDs (Display the result of ADC on Lcd display)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20080930:
       - initial release;
 * Description:
      A simple example of using the ADC library.
      ADC results are displayed on PORTB and PORTC.
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18FJ
                      http://www.mikroe.com/en/tools/lv18fj/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - Turn on PORTC and PORTB LEDs.
     - Select ADC module reference by placing jumper J5 (or J6) in proper position.
     - To simulate analog input on ADC channel 2, use on-board potentiometer P1 (or P2)
       http://www.mikroe.com/pdf/lv18fj_manual.pdf#page25
       by connecting jumper J5 (or J5) to MCU pin corresponding to ADC channel 2 input.
 */

unsigned int temp_res;

void main() {
  ADCON1 = 0b00001100;        // configure RA2 pin as analog
  TRISA  = 0xFF;              // PORTA is input
  TRISB  = 0;                 // PORTB is output
  TRISC  = 0;                 // PORTC is output

  do {
    temp_res = ADC_Read(2);   // Get results of AD conversion
    PORTC = temp_res;         // Send lower 8 bits to PORTC
    PORTB = temp_res >> 8;    // Send 2 most significant bits to RB1, RB0
  } while(1);                 // endless loop
}
