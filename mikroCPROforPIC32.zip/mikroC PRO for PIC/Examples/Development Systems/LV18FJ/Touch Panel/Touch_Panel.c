/*
 * Project name:
     TouchPanel (Demo for working with TouchPanel Controller)
 * Copyright:
     (c) mikroElektronika, 2008.
 * Revision History:
     20080930:
       - initial release;
 * Description:
     This code works with TouchPanel and GLCD. Two digital output and
     two analog input signals are used for communication with TouchPanel.
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18FJ
                      http://www.mikroe.com/en/tools/lv18fj/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    GLCD 128x64, Touch Panel
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * Notes:
     - Turn off PORTA LEDs, ADC jumpers and PORTA pull-up/down resistors,
       disconnect Ethernet LED jumpers J9 and J10. (board specific)
     - Turn on GLCD backlight and TouchPanel Contoller switches on LV18FJ board.
     - Since Touchpanel connector uses RD3 and RD4 pins on SW5, and PORTD of
       18F87J60 has only RD0, RD1 and RD2 pins, connect RD3 and RD4
       pins to RC3 and RC4 pins, respectively.
*/

// Glcd module connections
char GLCD_DataPort at PORTE;

sbit GLCD_CS1 at LATB0_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_CS2 at LATB1_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_RS  at LATB2_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_RW  at LATB3_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_EN  at LATB4_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_RST at LATB5_bit;  // for writing to output pin always use latch (PIC18 family)

sbit GLCD_CS1_Direction at TRISB0_bit;
sbit GLCD_CS2_Direction at TRISB1_bit;
sbit GLCD_RS_Direction  at TRISB2_bit;
sbit GLCD_RW_Direction  at TRISB3_bit;
sbit GLCD_EN_Direction  at TRISB4_bit;
sbit GLCD_RST_Direction at TRISB5_bit;
// End Glcd module connections

// Touch Panel module connections
sbit DRIVE_A at LATC3_bit;  // for writing to output pin always use latch (PIC18 family)
sbit DRIVE_B at LATC4_bit;  // for writing to output pin always use latch (PIC18 family)
sbit DRIVE_A_Direction at TRISC3_bit;
sbit DRIVE_B_Direction at TRISC4_bit;
const char READ_X_CHANNEL = 0;     // READ X line is connected to analog channel 0
const char READ_Y_CHANNEL = 1;     // READ Y line is connected to analog channel 1
// End Touch Panel module connections

bit          write_erase;
char         pen_size;
unsigned int x_coord, y_coord, x_coord_old, y_coord_old, x_coord_diff, y_coord_diff;
long         x_coord128, y_coord64;                       // scaled x-y position
int          cal_x_min, cal_y_min, cal_x_max, cal_y_max;  // calibration constants
char write_msg[] = "WRITE";                               // GLCD menu messages
char clear_msg[] = "CLEAR";
char erase_msg[] = "ERASE";
const unsigned int ADC_THRESHOLD = 900;                   // Threshold value for press detecting

// returns 1 if TouchPanel is pressed, 0 otherwise
char PressDetect() {
  unsigned adc_rd;
  char result;

  // PRESS detecting
  DRIVE_A = 0;         // DRIVEA = 0 (LEFT drive off, RIGHT drive off, TOP drive on)
  DRIVE_B = 0;         // DRIVEB = 0 (BOTTOM drive off)
  Delay_ms(5);

  adc_rd = ADC_Read(READ_Y_CHANNEL);      // READ-Y
  result = (adc_rd > ADC_THRESHOLD);      // if logical one is detectet

  //debouncing, repeat detecting after 2ms
  Delay_ms(2);
  adc_rd = ADC_Read(READ_Y_CHANNEL);      // READ-Y
  result = result & (adc_rd > ADC_THRESHOLD);
  return result;
}

unsigned int GetX() {
  unsigned int result;
  //reading X
  DRIVE_A = 1;          // DRIVEA = 1 (LEFT drive on, RIGHT drive on, TOP drive off)
  DRIVE_B = 0;          // DRIVEB = 0 (BOTTOM drive off)

  Delay_ms(5);
  result = ADC_Read(READ_X_CHANNEL);      // READ-X (BOTTOM)
  return result;
}

unsigned int GetY() {
  unsigned int result;
  //reading Y
  DRIVE_A = 0;          // DRIVEA = 0 (LEFT drive off, RIGHT drive off, TOP drive on)
  DRIVE_B = 1;          // DRIVEB = 1 (BOTTOM drive on)

  Delay_ms(5);
  result = ADC_Read(READ_Y_CHANNEL);      // READ-X (LEFT)
  return result;
}

void Calibrate() {

  Glcd_Dot(0,63,1);
  Glcd_Write_Text("TOUCH BOTTOM LEFT",12,3,1);
  while (!PressDetect());

  // get calibration constants (reading and compensating TouchPanel nonlinearity)
  cal_x_min = GetX() - 10;
  cal_y_min = GetY() - 10;
  Delay_ms(1000);

  Glcd_Fill(0);
  Glcd_Dot(127,0,1);
  Glcd_Write_Text("TOUCH UPPER RIGHT",12,4,1);
  while (!PressDetect()) ;

  // get calibration constants (reading and compensating TouchPanel nonlinearity)
  cal_x_max = GetX() + 5;
  cal_y_max = GetY() + 5;
  Delay_ms(1000);
}

void Initialize() {
  DRIVE_A_Direction = 0;       // Set DRIVE_A pin as output
  DRIVE_B_Direction = 0;       // Set DRIVE_B pin as output

  ADCON1 = 0b00001101;        // configure VDD as Vref, PORTA0 and PORTA1 pins as analog
  TRISA  = 0xFF;              // PORTA is input
  PORTA  = 0x00;              // Clear PORTA
  Glcd_Init();                // Initialize GLCD
}

void main() {

  Initialize();
  Glcd_Fill(0x00);                        // Clear GLCD
  Glcd_Set_Font(font5x7, 5, 7, 32);       // Choose font
  Glcd_Write_Text("CALIBRATION", 30, 2, 1);
  Delay_ms(1500);

  Glcd_Fill(0);
  Calibrate();
  Glcd_Fill(0);

  Glcd_Write_Text("WRITE ON SCREEN", 20, 5, 1) ;
  Delay_ms(1000);
  Glcd_Fill(0);

  Glcd_Fill(0);
  Glcd_V_Line(0,7,0,1);
  Glcd_Write_Text(clear_msg,1,0,0);
  Glcd_V_Line(0,7,97,1);
  Glcd_Write_Text(erase_msg,98,0,0);

  //Pen Menu:
  Glcd_Rectangle(41,0,52,9,1);
  Glcd_Box(45,3,48,6,1);
  Glcd_Rectangle(63,0,70,7,1);
  Glcd_Box(66,3,67,4,1);
  Glcd_Rectangle(80,0,86,6,1);
  Glcd_Dot(83,3,1);

  write_erase = 1;
  pen_size = 1;
  x_coord_old = 0;
  y_coord_old = 0;

 while (1) {

    if (PressDetect()) {
      // after a PRESS is detected read X-Y and convert it to 128x64 space
      x_coord = GetX() - cal_x_min;
      y_coord = GetY() - cal_y_min;

      // When lifting pen from the touchpanel surface GetX and GetY readings
      // (after correct PressDetect reading) may be incorrect
      x_coord_diff = abs(x_coord - x_coord_old);  // compare with old values
      y_coord_diff = abs(y_coord - y_coord_old);
      x_coord_old = x_coord;                      // save old values
      y_coord_old = y_coord;

      if ( (x_coord_diff>50) || (y_coord_diff>50) ) // if difference is too big then ignore the reading
        continue;

      x_coord128 = (x_coord * 128l) / (cal_x_max - cal_x_min);
      y_coord64 = (64 -(y_coord *64) / (cal_y_max - cal_y_min));

      if ((x_coord128 < 0) || (x_coord128 > 127))
        continue;
      if ((y_coord64 < 0) || (y_coord64 > 63))
        continue;

      //if clear is pressed
      if ((x_coord128 < 31) && (y_coord64 < 8)) {

        Glcd_Fill(0);

        //Pen Menu:
        Glcd_Rectangle(41,0,52,9,1);
        Glcd_Box(45,3,48,6,1);
        Glcd_Rectangle(63,0,70,7,1);
        Glcd_Box(66,3,67,4,1);
        Glcd_Rectangle(80,0,86,6,1);
        Glcd_Dot(83,3,1);

        Glcd_V_Line(0,7,0,1);
        Glcd_Write_Text(clear_msg,1,0,0);
        Glcd_V_Line(0,7,97,1);
        if (write_erase)
          Glcd_Write_Text(erase_msg,98,0,0);
        else
          Glcd_Write_Text(write_msg,98,0,0);
        }

      //if write/erase is pressed
      if ((x_coord128 > 96) && (y_coord64 < 8)) {
        if (write_erase) {
          write_erase = 0;
          Glcd_Write_Text(write_msg,98,0,0);
          Delay_ms(500);
          }
        else {
          write_erase = 1;
          Glcd_Write_Text(erase_msg,98,0,0);
          Delay_ms(500);
          }
        }

      //if pen size is selected
      if ((x_coord128 >= 41) && (x_coord128 <= 52) && (y_coord64 <= 9))
        pen_size = 3;

      if ((x_coord128 >= 63) && (x_coord128 <= 70) && (y_coord64 <= 7))
        pen_size = 2;

      if ((x_coord128 >= 80) && (x_coord128 <= 86) && (y_coord64 <= 6))
        pen_size = 1;

      if (y_coord64 < 11)
        continue;

      switch (pen_size) {
        case 1 : Glcd_Dot(x_coord128, y_coord64, write_erase); break;
        case 2 : Glcd_Box(x_coord128, y_coord64, x_coord128 + 1, y_coord64 + 1, write_erase); break;
        case 3 : Glcd_Box(x_coord128-1, y_coord64-1, x_coord128 + 2, y_coord64 + 2, write_erase); break;
        }

    }
  }

}
