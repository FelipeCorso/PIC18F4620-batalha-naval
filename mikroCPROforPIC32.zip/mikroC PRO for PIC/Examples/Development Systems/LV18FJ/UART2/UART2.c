/*
 * Project name:
     UART2 (Simple usage of UART module library functions)
 * Copyright:
     (c) Mikroelektronika, 2008.
 * Revision History:
     20080930:
       - initial release;
 * Description:
     This code demonstrates how to use UART library routines. Upon receiving
     data via RS232, MCU immediately sends it back to the sender.
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18FJ
                      http://www.mikroe.com/en/tools/lv18fj/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/en/compilers/mikroc/pro/pic/
 * NOTES:
     - RS232 RX and TX switches SW1.3 and SW1.4 should be turned On (board specific).
*/

char uart_rd;

void main() {
  ADCON1 |= 0x0F;                // Configure AN pins as digital
  CMCON  |= 7;                   // Disable comparators
  
  UART2_Init(9600);              // Initialize UART2 module at 9600 bps
  Delay_ms(100);                 // Wait for UART2 module to stabilize

  while (1) {                    // Endless loop
    if (UART2_Data_Ready()) {    // If data is received,
      uart_rd = UART2_Read();    //   read the received data,
      UART2_Write(uart_rd);      //   and send data via UART2
    }
  }
}
